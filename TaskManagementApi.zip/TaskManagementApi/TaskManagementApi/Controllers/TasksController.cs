﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManagementApi.Models;

namespace TaskManagementApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private static List<TaskItem> tasks = new()
        {
            new TaskItem { Id = 1, Title = "Изучить JWT", Description = "Разобраться, как устроен токен", IsCompleted = true },
            new TaskItem { Id = 2, Title = "Настроить аутентификацию", Description = "Подключить JwtBearer в Program.cs", IsCompleted = false },
            new TaskItem { Id = 3, Title = "Протестировать API", Description = "Проверить 200 и 401 в Swagger", IsCompleted = false }
        };

        [AllowAnonymous]
        [HttpGet]
        public ActionResult<List<TaskItem>> GetAll()
        {
            return Ok(tasks);
        }

        [AllowAnonymous]
        [HttpGet("{id}")]
        public ActionResult<TaskItem> GetById(int id)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound();
            return Ok(task);
        }

        [Authorize]
        [HttpPost]
        public IActionResult Create(TaskItem newTask)
        {
            if (newTask == null || string.IsNullOrWhiteSpace(newTask.Title))
                return BadRequest();

            var userName = HttpContext.User.Claims
                .FirstOrDefault(c => c.Type == "name")?.Value;

            newTask.Id = tasks.Any() ? tasks.Max(t => t.Id) + 1 : 1;
            tasks.Add(newTask);

            return CreatedAtAction(nameof(GetById), new { id = newTask.Id }, new
            {
                message = "Задача успешно добавлена",
                user = userName,
                task = newTask
            });
        }

        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound();

            var userName = HttpContext.User.Claims
                .FirstOrDefault(c => c.Type == "name")?.Value;

            tasks.Remove(task);

            return Ok(new
            {
                message = "Задача успешно удалена",
                user = userName
            });
        }
    }
}